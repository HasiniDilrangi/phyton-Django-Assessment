

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('', views.Base, name='Base'),
    # Add more URL patterns as needed
]
