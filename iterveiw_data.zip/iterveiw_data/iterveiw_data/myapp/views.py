from django.shortcuts import render
import pandas as pd

def index(request):
    # Read the CSV file into a DataFrame
    movies = pd.read_csv(r"C:\Users\DILRANGI\Downloads\Interview_dataset\Ganison_dataset\ganison_dataset_3.csv", sep=',')


    column1_data = movies['StudentID'].tolist()  
    column2_data = movies['First Name'].tolist()
    column3_data = movies['Subject'].tolist() 
    column4_data = movies['Answers'].tolist() 
    column5_data = movies['Class'].tolist() 
    column6_data = movies['Last Name'].tolist() 
    column7_data = movies['sydney_percentile'].tolist() 
     
    
    # Pass the column data to the template
    return render(request, "index.html", {'column1_data': column1_data, 'column2_data': column2_data,'column3_data': column3_data,'column4_data': column4_data,'column5_data': column5_data,'column6_data': column6_data,'column7_data': column7_data})





