                     
<h1 align="center" style="font-weight: bold;">Data Mining Using Python Django 💻</h1>


<p align="center">Simple description of what your project does or how to use it. I got only one Dataset. Because of computer is not Responding some time to very large Data Sets.</p>


 
<h2 id="technologies">💻 Technologies</h2>

Python Django Framework

pandas library

 
<h3>Starting</h3>

How to start my project 

cd iterveiw_data

code .

py manage.py runserver
